"use client"
import React from 'react'
import styles from "./staff.module.css"
import CardView from './dashboardComponents/CardView'

function page() {
    
    return (
        <>
            <div className={styles.main}>
                <div className={styles.placements}>
                    <p className={styles.title}>
                        Placements Overview
                    </p>
                    <div className={styles.placements_flex}>
                        <table className={styles.content_table}>
                            <thead className={styles.thead}>
                                <tr className={styles.tr}>
                                    <th className={styles.td}>S.no</th>
                                    <th className={styles.td}>Name</th>
                                    <th className={styles.td}>Roll Numbers</th>
                                    <th className={styles.td}>Company Name</th>
                                    <th className={styles.td}>Package(LPA)</th>
                                    <th className={styles.td}>Batch Year</th>
                                </tr>
                            </thead>
                            <tbody className={styles.tbody}>
                                <tr className={styles.tr}>
                                    <td className={styles.td}>1</td>
                                    <td className={styles.td}>Domenic</td>
                                    <td className={styles.td}>88,110</td>
                                    <td className={styles.td}>dcode</td>
                                    <td className={styles.td}>dcode</td>
                                    <td className={styles.td}>dcode</td>
                                </tr>
                                <tr className={styles.tr}>
                                    <td className={styles.td}>2</td>
                                    <td className={styles.td}>Sally</td>
                                    <td className={styles.td}>72,400</td>
                                    <td className={styles.td}>Students</td>
                                    <td className={styles.td}>dcode</td>
                                    <td className={styles.td}>dcode</td>
                                </tr>
                                <tr className={styles.tr}>
                                    <td className={styles.td}>3</td>
                                    <td className={styles.td}>Nick</td>
                                    <td className={styles.td}>52,300</td>
                                    <td className={styles.td}>dcode</td>
                                    <td className={styles.td}>dcode</td>
                                    <td className={styles.td}>dcode</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}

export default page