import Image from 'next/image'
import styles from './page.module.css'
import Link from 'next/link'

export default function Home() {
  return (
    <>
      <div className={styles.main_hero}>
        <div className={styles.main_left}>

          <div className={styles.text}>
            <Image src="/logo.png" width={100} height={100} />
            <p className={styles.txt}>LogIn to Administrator</p>
            <form>
              <div className={styles.main_form}>
                <div className={styles.input_field}>
                  <p className={styles.input_name}>
                    Email/Id
                  </p>
                  <input type='text' placeholder='Email/id' className={styles.input_entry} />
                </div>
                <div className={styles.input_field}>
                  <p className={styles.input_name}>
                    Password
                  </p>
                  <input type='text' placeholder='Password' className={styles.input_entry} />
                </div>
                <Link href="#" className={styles.input_forget}>
                  Forget Password
                </Link>
                <div>
                  <button type='button' className={styles.btn}>Login</button>
                </div>
                <p className={styles.txt_1}>If you are new to the portal,Contact Administrator</p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}
