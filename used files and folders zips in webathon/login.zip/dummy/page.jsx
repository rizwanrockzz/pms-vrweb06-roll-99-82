import React from 'react'
import Link from 'next/link'
import styles from "./login.module.css"
import Image from 'next/image'
function page() {
    return (
        <>
            <div className={styles.main}>
                <div className={styles.main_hero}>
                    <div className={styles.main_left}>
                        <div className={styles.text}>

                            <p className={styles.txt}>The key to happiness is to log in.</p>
                            <form>
                                <div className={styles.main_form}>
                                    <div className={styles.input_field}>
                                        <p className={styles.input_name}>
                                            Roll Number/Id
                                        </p>
                                        <input type='text' maxLength={10} placeholder='Roll Number/id' className={styles.input_entry} />
                                    </div>
                                    <div className={styles.input_field}>
                                        <p className={styles.input_name}>
                                            Password
                                        </p>
                                        <input type='password' placeholder='Password' className={styles.input_entry} />
                                    </div>
                                    <Link href="#" className={styles.input_forget}>
                                        Forget Password
                                    </Link>
                                    <div>
                                        <button type='button' className={styles.btn}>Login</button>
                                    </div>
                                    <p className={styles.txt_1}>If you are new to the portal,Contact Administrator</p>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div className={styles.main_right}>
                        <Image src="/logo.png" width={150} height={150} />
                        <p className={styles.head}>Velagapudi Ramakrishna Siddhartha Engineering College</p>
                    </div>
                </div>
            </div>

        </>
    )
}

export default page