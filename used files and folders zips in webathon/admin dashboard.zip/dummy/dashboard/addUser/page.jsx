'use client'
import React, { useState } from 'react'
import styles from "./user.module.css"

function page() {
    const [showCoordinatorForm, setShowCoordinatorForm] = useState(false);
    const [showStudentForm, setShowStudentForm] = useState(false);

    const toggleCoordinatorForm = () => {
        setShowCoordinatorForm(!showCoordinatorForm);
        setShowStudentForm(false); // Close student form if open
    };

    const toggleStudentForm = () => {
        setShowStudentForm(!showStudentForm);
        setShowCoordinatorForm(false); // Close coordinator form if open
    };

    const handleAddRollNumber = (event) => {
        const newRollNumber = event.target.value;
        if (newRollNumber.trim() !== '') {
            setRollNumbers([...rollNumbers, newRollNumber]);
            event.target.value = '';
        }
    };

    const handleRemoveRollNumber = (index) => {
        const updatedRollNumbers = [...rollNumbers];
        updatedRollNumbers.splice(index, 1);
        setRollNumbers(updatedRollNumbers);
    };

    const handleDepartmentChange = (event) => {
        setSelectedDepartment(event.target.value);
    };
    return (
        <div className={styles.main}>
            <div className={styles.placements}>
                <p className={styles.title}>
                    Add Users
                </p>
                <div className={styles.placements_flex}>
                    <button className={styles.card} onClick={toggleCoordinatorForm}>
                        <div className={styles.row_1}>
                            <div className={styles.row_1}>
                                {/* <div className={styles.dot_1}></div> */}
                                <p className={styles.stitle}>
                                    Add Department Coordinators
                                </p>
                            </div>
                            {/* <div className={styles.count}>{count}</div> */}
                        </div>
                    </button>
                    <button className={styles.card} onClick={toggleStudentForm}>
                        <div className={styles.row_1}>
                            <div className={styles.row_1}>
                                {/* <div className={styles.dot_2}></div> */}
                                <p className={styles.stitle}>
                                    Add Students
                                </p>
                            </div>
                            {/* <div className={styles.count}>{count}</div> */}
                        </div>
                    </button>
                </div>
            </div>
            <div className={styles.center}>
                {showCoordinatorForm && (
                    <div className={styles.form}>
                        <h2 className={styles.subtitle}>Add Department Coordinator</h2>
                        <form>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>
                                    First Name
                                </p>
                                <input type='text' name='fname' placeholder='First Name' className={styles.input_entry} />
                            </div>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>Last Name</p>
                                <input type="text" name="lname" placeholder="Last Name" className={styles.input_entry} />
                            </div>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>
                                    Email
                                </p>
                                <input type='email' name='email' placeholder='Email' className={styles.input_entry} />
                            </div>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>Department</p>
                                <select id="department" name="department" className={styles.input_entry}>
                                    <option value="CSE">CSE</option>
                                    <option value="IT">IT</option>
                                    <option value="ECE">ECE</option>
                                    <option value="MECH">MECH</option>
                                    <option value="EIE">EIE</option>
                                    <option value="CIVIL">CIVIL</option>
                                    {/* Add more department options as needed */}
                                </select>
                            </div>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>Coordinator ID</p>
                                <input type="text" id="coordinator" maxLength={6} name="coordinator" placeholder="Coordinator ID" className={styles.input_entry} />
                            </div>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>Password</p>
                                <input type="password" id="password" name="password" placeholder="Password" className={styles.input_entry} />
                            </div>

                            <div className={styles.input_field}>
                                <button type="submit" className={styles.btn}>Add Coordinator</button>
                            </div>
                        </form>
                    </div>
                )}

                {showStudentForm && (
                    <div className={styles.form}>
                        <h2 className={styles.subtitle}>Add Students</h2>
                        <form>
                        <div className={styles.input_field}>
                                <p className={styles.input_name}>
                                    Student ID
                                </p>
                                <input type='text' name='rollNumber' placeholder='Roll Number' className={styles.input_entry} />
                            </div>
                            <div className={styles.input_field}>
                                <p className={styles.input_name}>Department</p>
                                <select id="department" name="department" className={styles.input_entry}>
                                    <option value="CSE">CSE</option>
                                    <option value="IT">IT</option>
                                    <option value="ECE">ECE</option>
                                    <option value="MECH">MECH</option>
                                    <option value="EIE">EIE</option>
                                    <option value="CIVIL">CIVIL</option>
                                    {/* Add more department options as needed */}
                                </select>
                            </div>
                            <div className={styles.input_field}>
                                <button type="submit" className={styles.btn}>Add Student</button>
                            </div>
                        </form>
                    </div>
                )}
            </div>
        </div>
    )
}

export default page