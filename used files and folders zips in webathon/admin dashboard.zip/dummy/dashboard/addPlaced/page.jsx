import React from 'react'
import styles from "./placed.module.css"

function page() {
    return (
        <div className={styles.center}>
        <div className={styles.form}>
            <h2 className={styles.subtitle}>Add Placed Candidates</h2>
            <form>
                <div className={styles.input_field}>
                    <p className={styles.input_name}>
                        Name
                    </p>
                    <input type='text' name='fname' placeholder='Name' className={styles.input_entry} />
                </div>
                <div className={styles.input_field}>
                    <p className={styles.input_name}>Roll Number</p>
                    <input type="text" name="lname" placeholder="Roll Number" className={styles.input_entry} />
                </div>
                <div className={styles.input_field}>
                    <p className={styles.input_name}>Department</p>
                    <select id="department" name="department" className={styles.input_entry}>
                        <option value="CSE">CSE</option>
                        <option value="IT">IT</option>
                        <option value="ECE">ECE</option>
                        <option value="MECH">MECH</option>
                        <option value="EIE">EIE</option>
                        <option value="CIVIL">CIVIL</option>
                        {/* Add more department options as needed */}
                    </select>
                </div>
                <div className={styles.input_field}>
                    <p className={styles.input_name}>Company Name</p>
                    <input type="text" id="coordinator" maxLength={6} name="coordinator" placeholder="Company Name" className={styles.input_entry} />
                </div>
                <div className={styles.input_field}>
                    <p className={styles.input_name}>Package</p>
                    <input type="text" id="password" name="password" placeholder="Package" className={styles.input_entry} />
                </div>
                <div className={styles.input_field}>
                    <p className={styles.input_name}>Batch Year</p>
                    <input type="text" id="password" name="password" placeholder="Batch Year" className={styles.input_entry} />
                </div>

                <div className={styles.input_field}>
                    <button type="submit" className={styles.btn}>Send</button>
                </div>
            </form>
        </div>
        </div>
    )
}

export default page