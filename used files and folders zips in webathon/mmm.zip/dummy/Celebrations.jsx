"use client"
import React from 'react'
// import useWindowSize from 'react-use/lib/useWindowSize'
import Confetti from 'react-confetti'

function Celebrations() {
    // const { width, height } = useWindowSize()
  return (
    <Confetti
    width={900}
    height={200}
  />
  )
}

export default Celebrations